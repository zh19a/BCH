#coding=utf-8
#Zilin Huang

import sys

#read pdb file 
f=open("2FA9noend.pdb",'r')
lines=f.readlines()
f.close()


#claim valubles
records = []
mass = float(0)
xnew = float(0)
ynew = float(0)
znew = float(0)
atommass = float()
xgeo = float(0)
ygeo = float(0)
zgeo = float(0)
num = int(0)


for line in lines:
	#split each item and put into list records
	record = line.split()
	records.append(record) 
	#extract x, y, z, and atomname information
	x = float(record[6]) 
	y = float(record[7])
	z = float(record[8])
	atomname = record[11]

	#assign atom mass
	if atomname == 'C' :
		atommass = 12.01
	elif atomname == 'N' :
		atommass = 14.09
	elif atomname == 'O' :
		atommass = 16.00

	#sum the mass for mass center
	mass = mass + atommass
	xnew = float(xnew + x * atommass)
	ynew = float(ynew + y * atommass)
	znew = float(znew + z * atommass)
	#sum the mass for geometric center
	xgeo = float(xgeo + x)
	ygeo = float(ygeo + y)
	zgeo = float(zgeo + z)
	num = int(num + 1)
 
#mass center calculation
xmass_ave = float(xnew / mass)
ymass_ave = float(ynew / mass)
zmass_ave = float(znew / mass)

#geometry center calculation
xgeo_ave = float(xgeo / num)
ygeo_ave = float(ygeo / num)
zgeo_ave = float(zgeo / num)

#print the center based on user's choice 
choice=input("Do you want to center by mass or geometry 'M' or 'G': " )

#while choice != "mass" and choice != "geometric":
#     choice = raw_input("please choose the center: geometric or mass" )
if choice == "M":
	print("the mass center is: ", xmass_ave, ymass_ave, zmass_ave)
	x_center = float(xmass_ave)
	y_center = float(ymass_ave)
	z_center = float(zmass_ave)

elif choice == "G":
	print ("the geometric center is: ", xgeo_ave, ygeo_ave, zgeo_ave)
	x_center = float(xgeo_ave)
	y_center = float(ygeo_ave)
	z_center = float(zgeo_ave)
          
else:
	print("opps, typed chioce is not correct, try again! ")
     	
#generate centered pdb file based on the user's choice 
if choice == "M":
	outfile = open("2FA9.pdb_masscenter","w")

elif choice == "G":
	outfile = open("2FA9.pdb_geometriccenter","w")

#write the new file with proper format
for line in lines:
	record = line.split()
	record[6] = float(float(record[6]) - x_center)
	record[7] = float(float(record[7]) - y_center)
	record[8] = float(float(record[8]) - z_center)
	outfile.write("%4s%7d  %-4s%-4s%1s%4d    %8.3f%8.3f%8.3f%6.2f%6.2f%12.2s\n" % (record[0], int(record[1]), record[2], 
	record[3], record[4], int(record[5]), record[6], record[7], record[8], float(record[9]), float(record[10]), record[11]))   
	
outfile.close()
print ("Done! See the new pdf file.")