#coding=utf-8
#My name: Zilin Huang

import numpy as np
import pandas as pd
import sys 

#s = '2FA9noend.pdb' 

#read pdb file
#records = pd.read_csv(s, header=None, delim_whitespace = True, nrows = 1337).values

f=open("2FA9noend.pdb",'r')
lines=f.readlines()
f.close()



#write new pdb file
outfile = open('NEW_2FA9noend.pdb','w') 
records = []


for line in lines:
	records = line.split()
	outfile.write("%4s%7d  %-4s%-4s%1s%4d    %8.3f%8.3f%8.3f%6.2f%6.2f%12.2s\n" % (records[0], int(records[1]), records[2], 
	records[3], records[4], int(records[5]), float(records[6]), float(records[7]), float(records[8]), float(records[9]), float(records[10]), records[11]))

outfile.close()